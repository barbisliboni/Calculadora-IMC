package br.com.barbaraliboni.meuimc

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val txtMainAfinal : TextView = findViewById(R.id.txtMainAfinal);
        val txtMainAConta : TextView = findViewById(R.id.txtMainAConta);
        val txtMainLegal : TextView = findViewById(R.id.txtMainLegal);
        val edtnMainAltura : EditText = findViewById(R.id.edtnMainAltura);
        val edtnMainPeso : EditText = findViewById(R.id.edtnMainPeso);
        val txtMainObsAltura : TextView = findViewById(R.id.txtMainObsAltura);
        val txtMainObsPeso : TextView = findViewById(R.id.txtMainObsPeso);
        val btnMainCalcular : Button = findViewById(R.id.btnMainCalcular);

        val altura = edtnMainAltura.toString().toDouble()
        val peso = edtnMainPeso.toString().toDouble() //eu pesquisei e vi que preciso colocar um toString() ou uma string na frente do toDouble para ele funcionar
        val imc = peso/(altura*altura);

        btnMainCalcular.setOnClickListener {
                if(imc < 18.5){
                    val alert = AlertDialog.Builder(this)
                        .setTitle("IMC")
                        .setMessage("Seu IMC é de")
                        .setMessage("Você está abaixo do peso!")
                        .setNeutralButton("Sair"){_, _-> //arrumei isso
                        }
                        alert.show() //e isso
                }else if(imc >= 18.5 && imc <= 24.9){
                   // println("Você está no seu peso ideal!")
                }else if(imc >= 25 && imc <= 29.9){
                    //println("Você está sobrepeso!")
                }else if(imc >= 30 && imc <= 34.9){
                    //println("Você está com obesidade grau I")
                }else if(imc >= 35 && imc <= 39.9){
                    //println("Você está com obesidade grau II")
                }else{
                    //println("Você está com obesidade mórbida")
                }
            }
        }
    }
